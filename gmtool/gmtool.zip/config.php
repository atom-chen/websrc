<?php
header('Content-Type:text/html; charset=utf-8');
/*
    专业做后台30年，承接GM后台业务
              共享版本 请保留版权
    作者：老A
    联系：QQ273369457

*/
$config = array(
	'DB_HOST'=>'127.0.0.1',// 服务器地址
	'DB_NAME1'=>'lieyanzhetian_passport',// 游戏账号数据库
	'DB_NAME'=>'morningglory_data',// 游戏角色数据库
	'DB_USER'=>'root',// 用户名
	'DB_PWD'=>'xyfml@',// 密码
	'DB_PORT'=>3306,// 端口
	'DB_CHARSET'=>'utf8',// 数据库字符集
	'ADMIN_USER'=>'admin',   //后台管理员账号
	'ADMIN_PASS'=>'bbs.hnyinrui.com',   //后台管理员密码
);

?>