<!doctype html>
<?php
include "top.php"
?>
<div class="container clearfix">
    <?php 
	 include "memu.php"
	?>
    <!--/sidebar-->
    <?php
	 include "main.php"
	?>
    <!--/main-->
</div>
</body>
</html>